import React from 'react';
import logo from './logo.svg';
import './App.css';
import Main from './components/main.js';

function App() {
  return (
    <div className="App">
        <Main/>
    </div>
  );
}

export default App;
