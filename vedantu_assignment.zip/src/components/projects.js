import React from 'react';
import ListRepos from './list_repos.js';

class Bio extends React.Component{
    constructor(props){
        super(props);
        this.state = {current_tab: "repositories"}
    }

    componentDidMount(){
    }

    render(){
        return(
            <div>
                <div className="projects_nav">
                    <div>Overview</div>
                    <div>Repositories</div>
                    <div>Projects</div>
                </div>
                <div>
                    <div className="search_holder">
                        <input type="text" id="search" className="search"/>
                        <select name="cars" id="cars">
                          <option value="volvo">Volvo</option>
                          <option value="saab">Saab</option>
                          <option value="mercedes">Mercedes</option>
                          <option value="audi">Audi</option>
                        </select>
                        <select name="cars" id="cars">
                            <option value="volvo">Volvo</option>
                            <option value="saab">Saab</option>
                            <option value="mercedes">Mercedes</option>
                            <option value="audi">Audi</option>
                        </select>
                    </div>
                    <ListRepos/>
                </div>
            </div>
        )
    }
}

export default Bio
