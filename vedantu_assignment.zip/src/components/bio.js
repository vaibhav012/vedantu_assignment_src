import React from 'react';
import '../styles/main.css'

class Bio extends React.Component{
    constructor(props){
        super(props);
        this.state = {bio_data: {}}
    }

    componentDidMount(){
        fetch("https://api.github.com/users/supreetsingp47", {
            "method": 'GET'
        })
        .then(response => response.json())
        .then(data => {
            this.setState({
                bio_data: data
            })
        })
    }
    render(){
        return(
            <div className="bio_holder">
                <img src={this.state.bio_data.avatar_url} className="bio_avatar"/>
                <h2 className="bio_name">{this.state.bio_data.name}</h2>
                <br/>
                <p className="bio_name">{this.state.bio_data.login}</p>
                <br/>
                <p className="bio_name">{this.state.bio_data.bio}</p>
                <br/>
                <button>Follow</button>
                <br/>
                <p className="bio_name">{this.state.bio_data.followers + "Followers" + this.state.bio_data.followers + "Following" + this.state.bio_data.followers + "Star"}</p>
                <br/>
                <p className="bio_name">{this.state.bio_data.company}</p>
                <br/>
                <p className="bio_name">{this.state.bio_data.location}</p>
                <br/>
                <p className="bio_name">{"supreetsingh.247@gmail.com"}</p>
            </div>
        )
    }
}

export default Bio
